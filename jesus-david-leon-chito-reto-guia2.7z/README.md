# snnipets
- $1 -> para donde va
- ${1|opcion1,opcion2,opcion3|} -> opciones para escoger en ese punto
